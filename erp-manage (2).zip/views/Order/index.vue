<template>
  <div>
    我是Order页面
  </div>
</template>

<script>
export default {
  name: 'Order',
  data(){
    return{}
  }
}
</script>