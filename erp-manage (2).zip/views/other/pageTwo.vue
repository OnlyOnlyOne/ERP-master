<template>
  <div>
    我是page2页面
  </div>
</template>

<script>
export default {
  name: 'pageTwo',
  data(){
    return{}
  }
}
</script>