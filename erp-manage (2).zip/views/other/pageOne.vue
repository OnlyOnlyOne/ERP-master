<template>
  <div>
    我是page1页面
  </div>
</template>

<script>
export default {
  name: 'pageOne',
  data(){
    return{}
  }
}
</script>