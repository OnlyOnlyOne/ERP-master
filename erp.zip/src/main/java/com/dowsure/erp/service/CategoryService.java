package com.dowsure.erp.service;

import com.github.pagehelper.PageInfo;
import com.dowsure.erp.model.pojo.Category;
import com.dowsure.erp.model.request.AddcategoryReq;
import com.dowsure.erp.model.vo.CategoryVO;

import java.util.List;

/**
 * The interface Category service.
 * 分类目录Service
 */
public interface CategoryService {

    void add(AddcategoryReq addcategoryReq);

    void update(Category updateUpdate);

    void delete(Integer id);

    PageInfo listForAdmin(Integer pageNum, Integer pageSize);

    List<CategoryVO> listCategoryForCustomer(Integer parenId);
}
