package com.dowsure.erp.service;

public interface FinancialService {
}
