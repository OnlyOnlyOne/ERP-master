package com.dowsure.erp.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthShopController {
}
