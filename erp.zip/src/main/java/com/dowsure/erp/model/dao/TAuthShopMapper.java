package com.dowsure.erp.model.dao;

import com.dowsure.erp.model.pojo.TAuthShop;

public interface TAuthShopMapper {
    int deleteByPrimaryKey(Long id);

    int insert(TAuthShop record);

    int insertSelective(TAuthShop record);

    TAuthShop selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TAuthShop record);

    int updateByPrimaryKey(TAuthShop record);
}