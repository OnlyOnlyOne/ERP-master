<template>
  <div>
    我是home页面
  </div>
</template>

<script>
export default {
  name: 'home',
  data(){
    return{}
  }
}
</script>