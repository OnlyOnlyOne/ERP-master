<template>
  <div>
    我是User页面
  </div>
</template>

<script>
export default {
  name: 'Home',
  data(){
    return{}
  }
}
</script>