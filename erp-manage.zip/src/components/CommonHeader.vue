<template>
  <header>
    <div class="l-content">
      <el-button plain icon="el-icon-menu" size="mini"></el-button><h3 style="color: #fff">首页</h3>
    </div>
  </header>
</template>